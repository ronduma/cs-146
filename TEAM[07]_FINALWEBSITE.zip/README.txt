CS-146 Final Group Project

Ron Dumalagan, Himmat Garcha, Michael Lamaze, Shannon Nicole Dinio

To run the website, please use the Live Server extension found in Visual Studio Code, or any other method that can run a localhost server.
Otherwise, the website JavaScript functionality may not fully work due to the browser CORS policies.

